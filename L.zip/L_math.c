#include "L_math.h"


//�����ж����������
int L_arcTan(float x, float y)
{
	int left = 0;
	int right = arcTanListLength;
	int mid;
	float tanValue = x/y;
	
	//����10��
	for(int i=0; i<10; i++)
	{
		mid = (left + right)/2;
		
		if(tanValue > arcTan[mid])
		{
			left = mid;
		}
		else if(tanValue < arcTan[mid])
		{
			right = mid;
		}
	}
	
	return mid+1;
}

//��������ƽ����
float L_sqrt(float number)
{
	long i;
	float x, y;
	const float f = 1.5F;
	x = number * 0.5F;
	y = number;
	i = * ( long * ) &y;
	i = 0x5f3759df - ( i >> 1 );

	y = * ( float * ) &i;
	y = y * ( f - ( x * y * y ) );
	y = y * ( f - ( x * y * y ) );
	return number * y;
}


//
float To_180_(float x)
{
	return (x>180?(x-360):(x<-180?(x+360):x));
}


