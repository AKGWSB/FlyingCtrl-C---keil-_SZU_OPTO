#include <autoHightCtrl.h>

hightCtrl_DataStruct hightCtrlData;

//�������ݳ�ʼ��
void hightCtrl_DataInit()
{
	hightCtrlData.hight = 0;
	hightCtrlData.modFlag = 0;
	hightCtrlData.speed_z = 0;
	
	hightCtrlData.hightTarget = 0;
	hightCtrlData.err_hight = 0;
	hightCtrlData.speedTarget = 0;
	hightCtrlData.err_speed = 0;
	hightCtrlData.err_sum_speed = 0;
	hightCtrlData.output = 0;
}


//�������ݽӿ�--����:posFilterData.posZ_filter_value*0.95, posFilterData.speedZ_predict_value*0.22
void hightCtrl_GetData_2ms_(float hight, float speed_z)
{
	hightCtrlData.hight = hight;
	hightCtrlData.speed_z = speed_z;
}


//ģʽ״̬��־λ�ӿ�
int hightCtrl_GetModeFlag()
{
	return hightCtrlData.modFlag;
}


//ת�����ģʽ
void hightCtrl_ChangeTo_TakeOff()
{
	hightCtrlData.modFlag = 1;
}


//ת������ģʽ
void hightCtrl_ChangeTo_Down()
{
	hightCtrlData.modFlag = 2;
}


//ת������ģʽ
void hightCtrl_ChangeTo_Stay()
{
	hightCtrlData.modFlag = 0;
}


//ת������ģʽ
void hightCtrl_ChangeTo_Ready()
{
	hightCtrlData.modFlag = 3;
}

//---------------------------------------------------------------------------------------------//

//�����������--�⻷P�ڻ�PI
float hightCtrlOutput_2ms_()
{
	//�������
	hightCtrlData.err_hight = hightCtrlData.hightTarget - hightCtrlData.hight;
	hightCtrlData.speedTarget = hightCtrlData.err_hight*1.6;
	hightCtrlData.err_speed = hightCtrlData.speedTarget  - hightCtrlData.speed_z ;
	
	//�ٶ�������/�޷�
	hightCtrlData.err_sum_speed += hightCtrlData.err_speed ;
	LIMIT(hightCtrlData.err_sum_speed, -40000, 80000);
	
	//PI��������
	hightCtrlData.output = hightCtrlData.err_speed * 13 + hightCtrlData.err_sum_speed * 0.0005;
	
	return (LIMIT(hightCtrlData.output*0.02, 0, 100) + 600);
	
//	//����ģʽ
//	if(hightCtrlData.modFlag == 0)
//	{
//		hightCtrl_DataInit();
//		return 0;
//	}
//	//����ģʽ,�������
//	else if(hightCtrlData.modFlag == 3)
//	{
//		hightCtrl_DataInit();
//		return 200;
//	}
//	
//	//��½�ж�,������б�־λ�ͻ���
//	if(hightCtrlData.modFlag == 2 && hightCtrlData.hight < 190)
//	{
//		hightCtrl_DataInit();
//		return 0;
//	}
//	//����
//	else if(hightCtrlData.modFlag == 2 && hightCtrlData.hight >= 300)
//	{
//		
//		if(hightCtrlData.hightTarget >= -40)
//		{
//			hightCtrlData.hightTarget -= 0.3;
//		}
//		
//		return (LIMIT(hightCtrlData.output*0.02, -10, 70) + 540);
//	}
//	//���
//	else if(hightCtrlData.modFlag == 1)
//	{ 
//		
//		if(hightCtrlData.hightTarget <= 1000)
//		{
//			hightCtrlData.hightTarget += 1.5;
//		}
//		
//		return (LIMIT(hightCtrlData.output*0.02, 0, 100) + 570);
//	}
	
	//return 0;
}














